"use client";

import React, { forwardRef, useRef, useEffect, useState } from "react";
import { clsx } from "clsx";
import useEmblaCarousel, { type UseEmblaCarouselType } from "embla-carousel-react";
import { Menu, X, ChevronRight, Phone, MapPin, Clock, Instagram, Scissors, Award, Users, Sparkles, Star } from "lucide-react";
import { motion, useScroll, useTransform, useInView } from "framer-motion";

const cn = (...classes: (string | undefined | null | false)[]) => {
  return classes.filter(Boolean).join(" ");
};

interface ButtonProps extends React.ComponentPropsWithoutRef<"button"> {
  variant?: "outline" | "default" | "ghost";
  size?: "icon" | "default" | "sm" | "lg";
  asChild?: boolean;
}

const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "default", size = "default", asChild, children, ...props }, ref) => {
    const Comp = asChild ? "span" : "button";
    return (
      <Comp
        ref={ref as any}
        className={clsx(
          "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all duration-300 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 hover:scale-105 active:scale-95",
          variant === "default" && "bg-primary text-primary-foreground shadow-lg hover:shadow-xl hover:bg-primary/90",
          variant === "outline" && "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground hover:border-primary/50",
          variant === "ghost" && "hover:bg-accent hover:text-accent-foreground",
          size === "default" && "h-10 px-4 py-2",
          size === "sm" && "h-9 rounded-md px-3",
          size === "lg" && "h-11 rounded-md px-8",
          size === "icon" && "h-9 w-9",
          className
        )}
        {...props}
      >
        {children}
      </Comp>
    );
  }
);
Button.displayName = "Button";

type CarouselApi = UseEmblaCarouselType[1];
type UseCarouselParameters = Parameters<typeof useEmblaCarousel>;
type CarouselOptions = UseCarouselParameters[0];
type CarouselPlugin = UseCarouselParameters[1];

interface CarouselProps {
  opts?: CarouselOptions;
  plugins?: CarouselPlugin;
  orientation?: "horizontal" | "vertical";
  setApi?: (api: CarouselApi) => void;
}

type CarouselContextProps = {
  carouselRef: ReturnType<typeof useEmblaCarousel>[0];
  api: ReturnType<typeof useEmblaCarousel>[1];
  scrollPrev: () => void;
  scrollNext: () => void;
  canScrollPrev: boolean;
  canScrollNext: boolean;
} & CarouselProps;

const CarouselContext = React.createContext<CarouselContextProps | null>(null);

function useCarousel() {
  const context = React.useContext(CarouselContext);
  if (!context) throw new Error("useCarousel must be used within a <Carousel />");
  return context;
}

const Carousel = forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement> & CarouselProps>(
  ({ orientation = "horizontal", opts, setApi, plugins, className, children, ...props }, ref) => {
    const [carouselRef, api] = useEmblaCarousel({ ...opts, axis: orientation === "horizontal" ? "x" : "y" }, plugins);
    const [canScrollPrev, setCanScrollPrev] = React.useState(false);
    const [canScrollNext, setCanScrollNext] = React.useState(false);

    const onSelect = React.useCallback((api: CarouselApi) => {
      if (!api) return;
      setCanScrollPrev(api.canScrollPrev());
      setCanScrollNext(api.canScrollNext());
    }, []);

    const scrollPrev = React.useCallback(() => api?.scrollPrev(), [api]);
    const scrollNext = React.useCallback(() => api?.scrollNext(), [api]);

    const handleKeyDown = React.useCallback(
      (event: React.KeyboardEvent<HTMLDivElement>) => {
        if (event.key === "ArrowLeft") { event.preventDefault(); scrollPrev(); }
        else if (event.key === "ArrowRight") { event.preventDefault(); scrollNext(); }
      },
      [scrollPrev, scrollNext]
    );

    React.useEffect(() => { if (!api || !setApi) return; setApi(api); }, [api, setApi]);

    React.useEffect(() => {
      if (!api) return;
      onSelect(api);
      api.on("reInit", onSelect);
      api.on("select", onSelect);
      return () => { api?.off("select", onSelect); };
    }, [api, onSelect]);

    return (
      <CarouselContext.Provider value={{ carouselRef, api, opts, orientation: orientation || (opts?.axis === "y" ? "vertical" : "horizontal"), scrollPrev, scrollNext, canScrollPrev, canScrollNext }}>
        <div ref={ref} onKeyDownCapture={handleKeyDown} className={clsx("relative", className)} role="region" aria-roledescription="carousel" {...props}>
          {children}
        </div>
      </CarouselContext.Provider>
    );
  }
);
Carousel.displayName = "Carousel";

const CarouselContent = forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(({ className, ...props }, ref) => {
  const { carouselRef, orientation } = useCarousel();
  return (
    <div ref={carouselRef} className="overflow-hidden">
      <div ref={ref} className={clsx("flex", orientation === "horizontal" ? "-ml-4" : "-mt-4 flex-col", className)} {...props} />
    </div>
  );
});
CarouselContent.displayName = "CarouselContent";

const CarouselItem = forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(({ className, ...props }, ref) => {
  const { orientation } = useCarousel();
  return (
    <div ref={ref} role="group" aria-roledescription="slide"
      className={clsx("min-w-0 shrink-0 grow-0 basis-full", orientation === "horizontal" ? "pl-4" : "pt-4", className)}
      {...props} />
  );
});
CarouselItem.displayName = "CarouselItem";

const CarouselPrevious = forwardRef<HTMLButtonElement, React.ComponentProps<typeof Button>>(
  ({ className, variant = "outline", size = "icon", ...props }, ref) => {
    const { orientation, scrollPrev, canScrollPrev } = useCarousel();
    return (
      <Button ref={ref} variant={variant} size={size}
        className={clsx("absolute size-8 rounded-full", orientation === "horizontal" ? "bottom-0 left-1/2 -translate-x-16 translate-y-4" : "-top-12 right-1/2 -translate-x-1/2 rotate-90", className)}
        disabled={!canScrollPrev} onClick={scrollPrev} {...props}>
        <ChevronRight className="size-4 rotate-180" />
        <span className="sr-only">Previous slide</span>
      </Button>
    );
  }
);
CarouselPrevious.displayName = "CarouselPrevious";

const CarouselNext = forwardRef<HTMLButtonElement, React.ComponentProps<typeof Button>>(
  ({ className, variant = "outline", size = "icon", ...props }, ref) => {
    const { orientation, scrollNext, canScrollNext } = useCarousel();
    return (
      <Button ref={ref} variant={variant} size={size}
        className={clsx("absolute size-8 rounded-full", orientation === "horizontal" ? "bottom-0 right-1/2 translate-x-16 translate-y-4" : "-bottom-12 left-1/2 -translate-x-1/2 rotate-90", className)}
        disabled={!canScrollNext} onClick={scrollNext} {...props}>
        <ChevronRight className="size-4" />
        <span className="sr-only">Next slide</span>
      </Button>
    );
  }
);
CarouselNext.displayName = "CarouselNext";

const AnimatedSection = ({ children, className = "" }: { children: React.ReactNode; className?: string }) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  return (
    <motion.div ref={ref} initial={{ opacity: 0, y: 50 }} animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }} transition={{ duration: 0.6, ease: "easeOut" }} className={className}>
      {children}
    </motion.div>
  );
};

interface TestimonialData { text: string; name: string; rating: number; }

const testimonials: TestimonialData[] = [
  { text: "Trato cercano y profesional. Juanma es un excelente profesional que siempre sabe exactamente lo que necesitas. Resultados impecables cada vez.", name: "Carlos M.", rating: 5 },
  { text: "La mejor peluquería de Cáceres sin duda. Atención personalizada, productos ecológicos y un ambiente muy agradable. Totalmente recomendable.", name: "María G.", rating: 5 },
  { text: "Excelente relación calidad-precio. Siempre salgo satisfecho con el resultado. El equipo es muy profesional y atento.", name: "Javier R.", rating: 5 },
  { text: "Llevo años viniendo y nunca me han defraudado. Juanma es un crack, sabe exactamente cómo quiero el corte. Muy recomendable.", name: "Antonio L.", rating: 5 },
  { text: "Profesionalidad y buen trato. Me asesoran sobre el cuidado del cabello y siempre me dan buenos consejos. Muy contentos con el servicio.", name: "Laura S.", rating: 5 },
];

const FloatingParticle = ({ delay = 0 }: { delay?: number }) => (
  <motion.div
    className="absolute w-2 h-2 bg-primary/20 rounded-full"
    initial={{ x: 0, y: 0, opacity: 0 }}
    animate={{ x: [0, Math.random() * 100 - 50, 0], y: [0, Math.random() * -100, 0], opacity: [0, 1, 0] }}
    transition={{ duration: 3 + Math.random() * 2, delay, repeat: Infinity, ease: "easeInOut" }}
    style={{ left: `${Math.random() * 100}%`, top: `${Math.random() * 100}%` }}
  />
);

const BarbershopWebsite = () => {
  const [menuState, setMenuState] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { scrollYProgress } = useScroll();
  const opacity = useTransform(scrollYProgress, [0, 0.2], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 0.2], [1, 0.95]);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) { element.scrollIntoView({ behavior: "smooth" }); setMenuState(false); }
  };

  return (
    <div className="min-h-screen bg-background overflow-hidden">
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-primary/5" />
        <motion.div className="absolute inset-0 bg-gradient-to-tr from-primary/10 via-transparent to-primary/10"
          animate={{ opacity: [0.3, 0.5, 0.3] }} transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }} />
      </div>

      <motion.header initial={{ y: -100 }} animate={{ y: 0 }} transition={{ duration: 0.6, ease: "easeOut" }}>
        <nav data-state={menuState ? "active" : undefined}
          className={cn("fixed z-20 w-full transition-all duration-300", isScrolled && "bg-background/75 border-b border-border backdrop-blur-xl shadow-lg")}>
          <div className="mx-auto max-w-7xl px-6">
            <div className="relative flex flex-wrap items-center justify-between gap-6 py-4 lg:gap-0">
              <div className="flex w-full justify-between gap-6 lg:w-auto">
                <motion.button onClick={() => scrollToSection("hero")} className="flex items-center space-x-2" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <motion.div animate={{ rotate: 360 }} transition={{ duration: 20, repeat: Infinity, ease: "linear" }}>
                    <Scissors className="h-8 w-8 text-primary" />
                  </motion.div>
                  <span className="text-xl font-bold">Peluquería The Prince</span>
                </motion.button>

                <button onClick={() => setMenuState((s) => !s)} aria-label={menuState ? "Close Menu" : "Open Menu"}
                  className="relative z-20 -m-2.5 -mr-4 block cursor-pointer p-2.5 lg:hidden">
                  <Menu className={cn("m-auto size-6 duration-200", menuState && "rotate-180 scale-0 opacity-0")} />
                  <X className={cn("absolute inset-0 m-auto size-6 -rotate-180 scale-0 opacity-0 duration-200", menuState && "rotate-0 scale-100 opacity-100")} />
                </button>

                <div className="m-auto hidden size-fit lg:block">
                  <ul className="flex gap-1">
                    <li><Button variant="ghost" size="sm" onClick={() => scrollToSection("servicios")}>Servicios</Button></li>
                    <li><Button variant="ghost" size="sm" onClick={() => scrollToSection("testimonios")}>Testimonios</Button></li>
                    <li><Button variant="ghost" size="sm" onClick={() => scrollToSection("contacto")}>Contacto</Button></li>
                  </ul>
                </div>
              </div>

              <div className={cn("bg-background mb-6 hidden w-full flex-wrap items-center justify-end space-y-8 rounded-3xl border p-6 shadow-2xl lg:m-0 lg:flex lg:w-fit lg:gap-6 lg:space-y-0 lg:border-transparent lg:bg-transparent lg:p-0 lg:shadow-none", menuState && "block lg:flex")}>
                <div className="lg:hidden">
                  <ul className="space-y-6 text-base">
                    <li><button onClick={() => scrollToSection("servicios")} className="text-muted-foreground hover:text-foreground block duration-150">Servicios</button></li>
                    <li><button onClick={() => scrollToSection("testimonios")} className="text-muted-foreground hover:text-foreground block duration-150">Testimonios</button></li>
                    <li><button onClick={() => scrollToSection("contacto")} className="text-muted-foreground hover:text-foreground block duration-150">Contacto</button></li>
                  </ul>
                </div>
                <div className="flex w-full flex-col space-y-3 sm:flex-row sm:gap-3 sm:space-y-0 md:w-fit">
                  <Button size="sm" onClick={() => scrollToSection("contacto")}>Reservar Cita</Button>
                </div>
              </div>
            </div>
          </div>
        </nav>
      </motion.header>

      <section id="hero" className="relative pt-24 pb-12 sm:pt-32 sm:pb-24 bg-gradient-to-b from-muted to-background overflow-hidden">
        {[...Array(10)].map((_, i) => <FloatingParticle key={i} delay={i * 0.2} />)}
        <div className="mx-auto max-w-7xl px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, x: -50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.8, ease: "easeOut" }}>
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2, duration: 0.6 }}
                className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full mb-6">
                <Sparkles className="w-4 h-4" />
                <span className="text-sm font-medium">Valoración 4.9/5</span>
              </motion.div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight">
                <motion.span initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3, duration: 0.6 }} className="block">Tu estilo,</motion.span>
                <motion.span initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4, duration: 0.6 }}
                  className="block bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">nuestra pasión</motion.span>
              </h1>

              <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5, duration: 0.6 }} className="mt-6 text-lg text-muted-foreground">
                Peluquería profesional en el corazón de Cáceres. Más de 10 años de experiencia ofreciendo cortes modernos, cuidado personalizado y productos ecológicos de calidad.
              </motion.p>

              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6, duration: 0.6 }} className="mt-8 flex flex-wrap gap-4">
                <Button size="lg" onClick={() => scrollToSection("contacto")}>
                  Reservar Cita <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
                <Button size="lg" variant="outline" asChild>
                  <a href="https://www.instagram.com/peluqueriatheprince/" target="_blank" rel="noopener noreferrer">
                    <Instagram className="mr-2 h-4 w-4" /> Síguenos
                  </a>
                </Button>
              </motion.div>

              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7, duration: 0.6 }} className="mt-12 grid grid-cols-3 gap-6">
                {[{ value: "4.9", label: "Valoración", icon: Star }, { value: "40+", label: "Reseñas", icon: Users }, { value: "10+", label: "Años", icon: Award }].map((stat, index) => (
                  <motion.div key={stat.label} initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.8 + index * 0.1, duration: 0.5 }}
                    className="text-center bg-card/50 backdrop-blur-sm p-4 rounded-xl border border-border/50 hover:border-primary/50 transition-all duration-300"
                    whileHover={{ scale: 1.05, y: -5 }}>
                    <stat.icon className="w-5 h-5 text-primary mx-auto mb-2" />
                    <div className="text-3xl font-bold text-primary">{stat.value}</div>
                    <div className="text-sm text-muted-foreground">{stat.label}</div>
                  </motion.div>
                ))}
              </motion.div>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.8, ease: "easeOut" }} className="relative">
              <motion.div className="absolute -inset-4 bg-gradient-to-r from-primary/20 to-primary/10 rounded-3xl blur-2xl"
                animate={{ scale: [1, 1.05, 1], opacity: [0.5, 0.8, 0.5] }} transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }} />
              <motion.div className="aspect-square rounded-2xl bg-muted overflow-hidden shadow-2xl relative" whileHover={{ scale: 1.02, rotate: 1 }} transition={{ duration: 0.3 }}>
                <img src="https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=800&h=800&fit=crop" alt="Barbershop interior" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-background/60 to-transparent" />
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      <section id="servicios" className="py-12 sm:py-24 relative">
        <div className="mx-auto max-w-7xl px-6">
          <AnimatedSection className="text-center mb-12">
            <motion.div initial={{ opacity: 0, scale: 0.9 }} whileInView={{ opacity: 1, scale: 1 }} transition={{ duration: 0.5 }} viewport={{ once: true }}>
              <h2 className="text-3xl sm:text-4xl font-bold">Nuestros Servicios</h2>
              <p className="mt-4 text-lg text-muted-foreground">Servicios profesionales adaptados a tus necesidades</p>
            </motion.div>
          </AnimatedSection>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { icon: Scissors, title: "Cortes Modernos", description: "Cortes de cabello actuales y personalizados según tu estilo y tipo de cabello." },
              { icon: Award, title: "Productos Ecológicos", description: "Utilizamos productos de alta calidad, respetuosos con el medio ambiente y tu salud." },
              { icon: Users, title: "Atención Personalizada", description: "Asesoramiento profesional y trato cercano para cada cliente." },
            ].map((service, index) => (
              <AnimatedSection key={service.title}>
                <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.1, duration: 0.5 }} viewport={{ once: true }}
                  whileHover={{ y: -10, scale: 1.02 }} className="bg-card border border-border rounded-xl p-6 shadow-sm hover:shadow-xl transition-all duration-300 group h-full">
                  <motion.div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors duration-300" whileHover={{ rotate: 360 }} transition={{ duration: 0.6 }}>
                    <service.icon className="h-6 w-6 text-primary" />
                  </motion.div>
                  <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
                  <p className="text-muted-foreground">{service.description}</p>
                </motion.div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      <section id="testimonios" className="py-12 sm:py-24 bg-muted/50 relative overflow-hidden">
        <div className="mx-auto max-w-7xl px-6">
          <AnimatedSection className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold">Lo que dicen nuestros clientes</h2>
            <p className="mt-4 text-lg text-muted-foreground">Valoración de 4.9/5 basada en más de 40 reseñas</p>
          </AnimatedSection>
          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} viewport={{ once: true }}>
            <Carousel className="mx-auto max-w-4xl">
              <div className="relative">
                <CarouselContent>
                  {testimonials.map((testimonial, index) => (
                    <CarouselItem key={index}>
                      <div className="p-2 pb-5">
                        <motion.div initial={{ opacity: 0, scale: 0.9 }} whileInView={{ opacity: 1, scale: 1 }} transition={{ duration: 0.4 }} viewport={{ once: true }}
                          className="bg-card border border-border rounded-xl p-8 text-center shadow-sm hover:shadow-lg transition-all duration-300">
                          <div className="flex justify-center mb-4">
                            {[...Array(testimonial.rating)].map((_, i) => (
                              <motion.div key={i} initial={{ opacity: 0, scale: 0 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: i * 0.1, duration: 0.3 }}>
                                <svg className="w-5 h-5 text-yellow-400 fill-current" viewBox="0 0 20 20">
                                  <path d="M10 15l-5.878 3.09 1.123-6.545L.489 6.91l6.572-.955L10 0l2.939 5.955 6.572.955-4.756 4.635 1.123 6.545z" />
                                </svg>
                              </motion.div>
                            ))}
                          </div>
                          <p className="text-lg mb-6 italic">&ldquo;{testimonial.text}&rdquo;</p>
                          <div className="font-semibold">{testimonial.name}</div>
                        </motion.div>
                      </div>
                    </CarouselItem>
                  ))}
                </CarouselContent>
                <div className="pointer-events-none absolute inset-y-0 left-0 h-full w-2/12 bg-gradient-to-r from-muted/50"></div>
                <div className="pointer-events-none absolute inset-y-0 right-0 h-full w-2/12 bg-gradient-to-l from-muted/50"></div>
              </div>
              <div className="hidden md:block"><CarouselPrevious /><CarouselNext /></div>
            </Carousel>
          </motion.div>
        </div>
      </section>

      <section id="contacto" className="py-12 sm:py-24">
        <div className="mx-auto max-w-7xl px-6">
          <div className="grid lg:grid-cols-2 gap-12">
            <AnimatedSection>
              <h2 className="text-3xl sm:text-4xl font-bold mb-6">Visítanos</h2>
              <p className="text-lg text-muted-foreground mb-8">
                Estamos en el centro de Cáceres, en el Casco Antiguo. Reserva tu cita y descubre por qué somos la peluquería mejor valorada de la ciudad.
              </p>
              <div className="space-y-6">
                {[
                  { icon: MapPin, title: "Dirección", content: <span>Calle Jesús Asunción 19<br />Centro - Casco Antiguo<br />10002, Cáceres</span> },
                  { icon: Phone, title: "Teléfono", content: <a href="tel:+34633938833" className="text-muted-foreground hover:text-primary transition-colors">+34 633 93 88 33</a> },
                  { icon: Clock, title: "Horario", content: <div className="space-y-1"><p>Lunes - Viernes: 10:00 - 14:00, 17:00 - 20:00</p><p>Sábado: 10:00 - 14:00</p><p>Domingo: Cerrado</p></div> },
                ].map((item, index) => (
                  <motion.div key={item.title} initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} transition={{ delay: index * 0.1, duration: 0.5 }} viewport={{ once: true }} className="flex items-start gap-4 group">
                    <motion.div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 group-hover:bg-primary/20 transition-colors" whileHover={{ scale: 1.1, rotate: 360 }} transition={{ duration: 0.5 }}>
                      <item.icon className="h-5 w-5 text-primary" />
                    </motion.div>
                    <div>
                      <h3 className="font-semibold mb-1">{item.title}</h3>
                      <div className="text-muted-foreground">{item.content}</div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </AnimatedSection>

            <AnimatedSection>
              <motion.div initial={{ opacity: 0, scale: 0.95 }} whileInView={{ opacity: 1, scale: 1 }} transition={{ duration: 0.5 }} viewport={{ once: true }}
                className="bg-card border border-border rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <h3 className="text-2xl font-bold mb-6">Reserva tu cita</h3>
                <div className="space-y-4">
                  {[
                    { label: "Nombre", type: "text", placeholder: "Tu nombre", delay: 0.1 },
                    { label: "Teléfono", type: "tel", placeholder: "+34 600 000 000", delay: 0.2 },
                  ].map((field) => (
                    <motion.div key={field.label} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} transition={{ delay: field.delay, duration: 0.4 }} viewport={{ once: true }}>
                      <label className="block text-sm font-medium mb-2">{field.label}</label>
                      <input type={field.type} className="w-full px-4 py-2 border border-input rounded-md bg-background focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300" placeholder={field.placeholder} />
                    </motion.div>
                  ))}
                  <motion.div initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} transition={{ delay: 0.3, duration: 0.4 }} viewport={{ once: true }}>
                    <label className="block text-sm font-medium mb-2">Servicio</label>
                    <select className="w-full px-4 py-2 border border-input rounded-md bg-background focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300">
                      <option>Corte de cabello</option>
                      <option>Corte + barba</option>
                      <option>Afeitado</option>
                      <option>Tratamiento capilar</option>
                    </select>
                  </motion.div>
                  <motion.div initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} transition={{ delay: 0.4, duration: 0.4 }} viewport={{ once: true }}>
                    <label className="block text-sm font-medium mb-2">Mensaje (opcional)</label>
                    <textarea rows={4} className="w-full px-4 py-2 border border-input rounded-md bg-background focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300" placeholder="Cuéntanos qué necesitas..." />
                  </motion.div>
                  <motion.div initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} transition={{ delay: 0.5, duration: 0.4 }} viewport={{ once: true }}>
                    <Button size="lg" className="w-full">Enviar solicitud</Button>
                  </motion.div>
                </div>
              </motion.div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      <footer className="bg-muted py-12 relative overflow-hidden">
        <motion.div className="absolute inset-0 bg-gradient-to-t from-primary/5 to-transparent" initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} transition={{ duration: 1 }} viewport={{ once: true }} />
        <div className="mx-auto max-w-7xl px-6 relative z-10">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} viewport={{ once: true }}
            className="flex flex-col md:flex-row justify-between items-center gap-6">
            <motion.div className="flex items-center space-x-2" whileHover={{ scale: 1.05 }}>
              <Scissors className="h-6 w-6 text-primary" />
              <span className="font-bold">Peluquería The Prince</span>
            </motion.div>
            <motion.div className="flex gap-6" initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} transition={{ delay: 0.2, duration: 0.6 }} viewport={{ once: true }}>
              <motion.a href="https://www.instagram.com/peluqueriatheprince/" target="_blank" rel="noopener noreferrer"
                className="text-muted-foreground hover:text-primary transition-colors" whileHover={{ scale: 1.2, rotate: 360 }} transition={{ duration: 0.3 }}>
                <Instagram className="h-5 w-5" />
              </motion.a>
            </motion.div>
            <motion.p className="text-sm text-muted-foreground" initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} transition={{ delay: 0.3, duration: 0.6 }} viewport={{ once: true }}>
              © 2024 Peluquería The Prince. Todos los derechos reservados.
            </motion.p>
          </motion.div>
        </div>
      </footer>
    </div>
  );
};

export default BarbershopWebsite;
