import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Peluquería The Prince | Cáceres",
  description:
    "Peluquería profesional en el corazón de Cáceres. Más de 10 años de experiencia ofreciendo cortes modernos, cuidado personalizado y productos ecológicos de calidad.",
  keywords: ["peluquería", "Cáceres", "corte de cabello", "barbería", "The Prince"],
  openGraph: {
    title: "Peluquería The Prince | Cáceres",
    description: "La peluquería mejor valorada de Cáceres. Valoración 4.9/5.",
    locale: "es_ES",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
