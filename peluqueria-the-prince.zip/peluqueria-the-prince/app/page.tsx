import BarbershopWebsite from "@/components/BarbershopWebsite";

export default function Home() {
  return <BarbershopWebsite />;
}
