# Peluquería The Prince

Web oficial de **Peluquería The Prince**, Cáceres.

## Stack

- [Next.js 14](https://nextjs.org/) — App Router
- [Tailwind CSS](https://tailwindcss.com/)
- [Framer Motion](https://www.framer.com/motion/)
- [Embla Carousel](https://www.embla-carousel.com/)
- [Lucide React](https://lucide.dev/)

## Instalación

```bash
npm install
npm run dev
```

Abre [http://localhost:3000](http://localhost:3000) en tu navegador.

## Despliegue

Desplegado en [Vercel](https://vercel.com). Conecta el repositorio y se despliega automáticamente.
